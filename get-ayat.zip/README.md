# Get Ayat

Addons Firefox untuk mendapatkan nomor juz, nama surat, dan nomor ayat berdasarkan nomor halaman
