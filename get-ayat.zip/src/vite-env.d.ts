/// <reference types="svelte" />
/// <reference types="vite/client" />
/// <reference types="vite-plugin-pages-svelte/client" />
